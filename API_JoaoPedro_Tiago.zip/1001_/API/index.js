const e = require('express')
const express = require('express')
const server = express()
const mysql = require('mysql2')
const banco = mysql.createPool({
    host: 'localhost',
    port: 3306,
    database: '2e_ga_210922',
    user: 'root',
    password: 'Jp162636'    
})

const bodyParser = require('body-parser')

server.use(bodyParser.urlencoded({extended:false}))
server.use(bodyParser.json())


/* 1 Cadastrar veículos */
server.post("/veiculos/cadastro", (req,res,next) =>{
    let body = req.body
    const QUERY = `INSERT INTO veiculos (modelo, marca, preco_venda, proprietario) VALUES('${body.modelo}', '${body.marca}', ${body.preco_venda}, '${body.proprietario}')`

    banco.getConnection((error,conn) =>{
        if(error){
            return res.status(500).send({
                Mensagem:"Erro no servidor",
                Detalhes: error
            })
        }

        conn.query( QUERY,(error,resultado) => {
            conn.release()

            if(error){
                return res.status(500).send({
                    Mensagem:"Erro no servidor",
                    Detalhes:error
                })
            }

            return res.status(200).send({
                Mensagem:"Cadastro Realizado com sucesso"
            })
        })
    })
})

/* 2 Exibir todos os dados de todos os veículos ordenados pela marca */
server.get("/veiculos/exibir", (req,res,next) => {
    const QUERY = 'SELECT * FROM veiculos ORDER BY marca'

    banco.getConnection((error,conn) =>{
        if(error){
            return res.status(500).send({
                Erro: "Não foi pessível atender á solicitação",
                Detalhes: error
            })
        }

        conn.query(QUERY,(error, resultado) => {
            conn.release()

            if(error){
                return res.status(500).send({
                    Erro:"Não foi possivel atender à solicitação",
                    Detalhes: error
                })
            }

            return res.status(200).send({
                Mensagem: "Dados retornados com sucesso",
                Dados:resultado
            })
        })
    })
})


/* 3 Exibir todos os dados dos veículos de uma determinada marca, passada por parâmetro de URL */
server.get("/veiculos/exibir_marca/:marca",(req,res,next) =>{
    let marca = req.params.marca
    const QUERY = `SELECT * FROM veiculos WHERE marca LIKE '%${marca}%' ORDER BY
marca`

    banco.getConnection((error,conn) => {
        if(error){
            return res.status(500).send({
                Erro: "Não foi possivel atender à solicitação",
                Detalhes: error
            })
        }

        conn.query(QUERY,(error,resultado) =>{
            conn.release()

            if(error){
                return res.status(500).send({
                    Erro:"Não foi possível atender à solicitação",
                    Detalhes: console.error
                })
            }

            return res.status(200).send({
                Mensagem: "Consulta realizada com sucesso",
                Dados: resultado
            })
        })
    })

})

/* 4 Exibir todos os dados dos veículos de um determinado proprietário, passado por parâmetro de URL */
server.get("/veiculos/exibir_proprietario/:proprietario",(req,res,next) =>{
    let proprietario = req.params.proprietario
    const QUERY = `SELECT * FROM veiculos WHERE proprietario LIKE '%${proprietario}%' ORDER BY
    proprietario`

    banco.getConnection((error,conn) => {
        if(error){
            return res.status(500).send({
                Erro: "Não foi possivel atender à solicitação",
                Detalhes: error
            })
        }

        conn.query(QUERY,(error,resultado) =>{
            conn.release()

            if(error){
                return res.status(500).send({
                    Erro:"Não foi possível atender à solicitação",
                    Detalhes: error
                })
            }

            return res.status(200).send({
                Mensagem: "Consulta realizada com sucesso",
                Dados: resultado
            })
        })
    })


})

/* 5 Exibir todos os veículos com valor maior ou igual ao valor passado no parâmetro da URL */
server.get("/veiculos/exibir/:preco",(req,res) =>{
    let preco = req.params.preco
    const QUERY = `SELECT * FROM veiculos WHERE preco_venda >= ${preco}`;

    banco.getConnection((error,conn) => {
        if(error){
            return res.status(500).send({
                Erro: "Não foi possivel atender à solicitação",
                Detalhes: error
            })
        }

        conn.query(QUERY,(error,resultado) =>{
            conn.release()

            if(error){
                return res.status(500).send({
                    Erro:"Não foi possível atender à solicitação",
                    Detalhes: error
                })
            }

            return res.status(200).send({
                Mensagem: "Consulta realizada com sucesso",
                Dados: resultado
            })
        })
    })


})

/* 6 Alterar os dados de um veículo, utilizando como critério o ID */
server.patch("/veiculos/editar/:id",(req,res,next) => {
    let id = req.params.id
    let body = req.body
    const SQL = `UPDATE veiculos SET modelo = '${body.modelo}', marca = '${body.marca}', preco_venda = ${body.preco_venda}, proprietario = '${body.proprietario}' WHERE id = ${id}`;

    banco.getConnection((erro,con) =>{
        if(erro){
            return res.status(500).send({
                mensagem:'Erro no servidor',
                detalhes: erro
            })
        }

        con.query(SQL,(erro,result) =>{
            con.release()
            if(erro){
                return res.status(500).send({
                    mensagem:'Erro ao atualizar o cadastro',
                    detalhes: erro
                })
            }

            return res.status(200).send({
                mensagem:'Cliente atualizado com sucesso!'
            })
        })
    })
})

/* 7 Excluir um veículo pelo ID */
 server.delete("/veiculos/deletar_id/:id", (req,res,next) =>{
    let id = req.params.id
    const QUERY = `DELETE FROM veiculos WHERE id=${id}`
    
    banco.getConnection((error,conn)=>{
        if(error){
            return res.status(500).send({
                mensagem:`Erro no servidor`,
                detalhes:error
            })
        }

        conn.query(QUERY,(erro,resultados) => {
            conn.release()

            if(erro){
                return res.status(500).send({
                    mensagem:`Não foi possivel excluiir o cliente ${id}`,
                    detalhes:erro
                })
            }

            if(resultados.affectedRows > 0){
                return res.status(200).send({
                    mensagem: `Cliente ${id} excluido com sucesso`
                })
            }else{
                return res.status(200).send({
                    mensagem:`Cliente ${id} não existe no banco de dados`
                })
            }
        })
    })
})

/* 8 Excluir todos os veículos de uma determinada marca, passada por parâmetro de URL*/
server.delete("/veiculos/deletar_marca/:marca", (req,res,next) =>{
    let marca = req.params.marca
    const QUERY = `DELETE FROM veiculos WHERE marca= '${marca}'`;
    
    banco.getConnection((error,conn)=>{
        if(error){
            return res.status(500).send({
                mensagem:`Erro no servidor`,
                detalhes:error
            })
        }

        conn.query(QUERY,(erro,resultados) => {
            conn.release()

            if(erro){
                return res.status(500).send({
                    mensagem:`Não foi possivel excluiir a marca ${marca}`,
                    detalhes:erro
                })
            }

            if(resultados.affectedRows > 0){
                return res.status(200).send({
                    mensagem: `Marca ${marca} excluida com sucesso`
                })
            }else{
                return res.status(200).send({
                    mensagem:`Marca ${marca} não existe no banco de dados`
                })
            }
        })
    })
})

/* 9 Excluir todos os veículos de um determinado modelo e que tenha um preço de venda maior ou igual ao informado, valores passados por parâmetro de URL; */
server.delete("/veiculos/deletar_ModeloPreco/:modelo/:preco_venda", (req,res,next) =>{
    let modelo = req.params.modelo
    let preco_venda = req.params.preco_venda
    const QUERY = `DELETE FROM veiculos WHERE modelo='${modelo}' && preco_venda >= '${preco_venda}' `
    
    banco.getConnection((error,conn)=>{
        if(error){
            return res.status(500).send({
                mensagem:`Erro no servidor`,
                detalhes:error
            })
        }

        conn.query(QUERY,(erro,resultados) => {
            conn.release()

            if(erro){
                return res.status(500).send({
                    mensagem:`Não foi possivel excluiir o modelo ${modelo}`,
                    detalhes:erro
                })
            }

            if(resultados.affectedRows > 0){
                return res.status(200).send({
                    mensagem: `Modelo ${modelo} excluido com sucesso`
                })
            }else{
                return res.status(200).send({
                    mensagem:`Modelo ${modelo} com valor menor que ${preco_venda} não existe no banco de dados`
                })
            }
        })
    })
})



server.get('/', (req, res, next) => {
    return res.status(200).send({
        mensagem: "Servidor Funcionado"
    })
})
    
server.listen(3000, () => {
    console.log("Executando")
})



























 
